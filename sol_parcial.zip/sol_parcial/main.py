import gui

if __name__ == "__main__":
    print("Iniciando programa...")
    gui.main()